import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

const logo = "/public/logo.png";
const visaImg = "/public/visa.png";
const mastercardImg = "/public/mastercard.png";

const cards = [
  {
    id: 1,
    name: "VISA 10$ - 5 CARD",
    price: "$10",
    description: "5 штук VISA карт по 10$",
    image: visaImg
  },
  {
    id: 2,
    name: "MASTERCARD 10$ - 5 CARD",
    price: "$10",
    description: "5 штук MASTERCARD карт по 10$",
    image: mastercardImg
  }
];

function Header() {
  return (
    <header style={{ background: 'black', padding: '1rem', color: '#22c55e' }}>
      <Link to="/">
        <img src={logo} alt="Credit Card Shop" style={{ height: 50 }} />
      </Link>
      <nav style={{ marginLeft: '2rem' }}>
        <Link to="/catalog" style={{ marginRight: 10 }}>Каталог</Link>
        <Link to="/cart">Корзина</Link>
      </nav>
    </header>
  );
}

function Footer() {
  return (
    <footer style={{ textAlign: 'center', padding: '1rem', borderTop: '1px solid gray', color: 'gray' }}>
      © 2025 Credit Card Shop · Email: <a href="mailto:creditcardshop555@gmail.com" style={{ color: '#22c55e' }}>creditcardshop555@gmail.com</a> · Telegram: <a href="https://t.me/CARDSHOPCREDIT" style={{ color: '#22c55e' }}>@CARDSHOPCREDIT</a>
    </footer>
  );
}

function Home() {
  return (
    <main style={{ padding: '2rem', textAlign: 'center' }}>
      <h1 style={{ fontSize: 32, color: '#22c55e' }}>Добро пожаловать в Credit Card Shop</h1>
      <p style={{ color: '#ccc' }}>Покупайте премиальные карты с мгновенной доставкой</p>
      <Link to="/catalog">
        <button style={{ background: '#22c55e', color: 'black', padding: '0.5rem 1rem', marginTop: '1rem' }}>Смотреть карты</button>
      </Link>
    </main>
  );
}

function Catalog() {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', padding: '1rem' }}>
      {cards.map(card => (
        <div key={card.id} style={{ background: '#111', padding: '1rem', color: 'white' }}>
          <img src={card.image} alt={card.name} style={{ width: '100%', height: 100, objectFit: 'contain' }} />
          <h2 style={{ color: '#22c55e' }}>{card.name}</h2>
          <p>{card.description}</p>
          <p style={{ fontWeight: 'bold' }}>{card.price}</p>
          <button style={{ background: '#22c55e', color: 'black', padding: '0.5rem 1rem', marginTop: '0.5rem' }}>Купить</button>
        </div>
      ))}
    </div>
  );
}

function Cart() {
  const [showPayment, setShowPayment] = useState(false);

  return (
    <div style={{ padding: '2rem', color: 'white' }}>
      <h2 style={{ color: '#22c55e' }}>Корзина</h2>
      <p>Ваша корзина пока пуста.</p>
      <button onClick={() => setShowPayment(true)} style={{ background: '#22c55e', color: 'black', padding: '0.5rem 1rem', marginTop: '1rem' }}>
        Оплатить криптовалютой
      </button>
      {showPayment && (
        <div style={{ marginTop: '2rem', background: '#222', padding: '1rem', borderRadius: '0.5rem' }}>
          <h3 style={{ color: '#22c55e' }}>Переведите BTC на:</h3>
          <p>bc1q4prcj9mxverlhdu4dj6229xqnegqphqyyzk873</p>
          <h3 style={{ color: '#22c55e' }}>Или USDT на:</h3>
          <p>0xa5EE0769A87C3B113B790EfbD8cd04117Ebb6715</p>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/catalog" element={<Catalog />} />
        <Route path="/cart" element={<Cart />} />
      </Routes>
      <Footer />
    </Router>
  );
}
